/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClientSrc;

import java.util.Vector;
/**
 *
 * @author sivan
 */
public class ClientParser {
    
    public Vector<String> parseToVec(String serverResponse){
        Vector<String> ans = new Vector<String>();
        if(!serverResponse.isEmpty()){
            String[] allElements = serverResponse.split(Configuration.DELIMITER1);
            for(int i=0; i<allElements.length; i++)
                ans.add(allElements[i]);
        }
        return ans;
    } 

    public int parseToInt(String serverResponse) {
        int ans = 0;
        for(int i=0; i<serverResponse.length(); i++)
            ans = (ans*10) + (serverResponse.charAt(i)-48);
        return ans;
    }
    
    public boolean parseToBool(String serverResponse) {
        if(serverResponse.startsWith(Configuration.SUCCESS))
            return true;
        return false;
    }
}
