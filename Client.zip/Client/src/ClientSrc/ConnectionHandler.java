/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/

package ClientSrc;

import java.io.*;
import java.net.*;
import java.util.Vector;
import java.util.logging.Level;

/**
 *
 * @author Vali
 */
public class ConnectionHandler implements ServerHandlerInterface{
    
    ClientParser parser = new ClientParser();
    private String msg = null;
    
    PrintWriter out;
    BufferedReader in;
    Socket socket;
    private String method;
    
    
    
    
    public ConnectionHandler(){
//            try {
//                //listenSocket();
//           
//                start();
//            } catch (IOException ex) {
//                java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
//            }
        
        
        
        
    }
    
    
    public String start() throws IOException {
        Socket lpSocket = null; // the connection socket
        PrintWriter out = null;
        
        // Get host and port
        String host = Configuration.IP;
        int port = Configuration.PORT;
        
        System.out.println("Connecting to " + host + ":" + port);
        
        // Trying to connect to a socket and initialize an output stream
        try {
            lpSocket = new Socket(host, port); // host and port
            out = new PrintWriter(lpSocket.getOutputStream(), true);
        } catch (UnknownHostException e) {
            System.out.println("Unknown host: " + host);
            System.exit(1);
        } catch (IOException e) {
            System.out.println("Couldn't get I/O to " + host + " connection");
            System.exit(1);
        }
        
        System.out.println("Connected to server!");
        
//            String msg=this.msg;
//            BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
        
//            while ((msg = userIn.readLine())!= null)
        
        out.println(msg);//
        
        String ansFromServer = null;
        try {
            BufferedReader clientBR = new BufferedReader(new InputStreamReader(lpSocket.getInputStream()));
            ansFromServer = clientBR.readLine();
            System.out.println("Server response: " + ansFromServer);
        }
        catch (IOException e) {
            System.out.println("Something went really wrong.. \nI can't recieve messages from the server!!");
//                temp = e.toString();
        }
        System.out.println("Exiting...");
        
        // Close all I/O
        out.close();
//            userIn.close();
        lpSocket.close();
        
        return ansFromServer;
    }
  

    @Override//
    public Vector<String> DisplayForums() {
        String serverResponse = "";
        this.msg = Configuration.DisplayForums;
          try {
              //listenSocket();
              serverResponse = start();
          } catch (IOException ex) {
               java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
          }
          this.msg = null;
          return parser.parseToVec(serverResponse);
    }

    @Override//
    public String registerToForum(String userName, String forumName, String password, String Email, String remainderQues, String remainderAns) {
        String response = "";
        this.msg = Configuration.registerToForum + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + 
                forumName + Configuration.DELIMITER1 + password + Configuration.DELIMITER1 +
                Email + Configuration.DELIMITER1 + remainderQues + Configuration.DELIMITER1 + remainderAns;
        try {
            //listenSocket();
            response = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return response;
    }

    @Override//
    public String login(String forumName, String userName, String password) {
        String response = "";
        this.msg = Configuration.login +  Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1
                + userName + Configuration.DELIMITER1 + password;
        try {
            //listenSocket();
            response = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return response;
    }

    @Override//
    public boolean logout(String forumName, String userName) {
        String serverResponse = "";
        this.msg = Configuration.logout + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + userName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public Vector<String> getSubForums(String forumName) {
        String serverResponse = "";
        this.msg = Configuration.getSubForums + Configuration.DELIMITER1 + forumName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public Vector<String> getThreads(String forumName, String subForumName) {
        String serverResponse = "";
        this.msg = Configuration.getThreads + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override
    public String getThreadContent(String treadID, String subForumName, String forumName) {
        String serverResponse = "";
        this.msg = Configuration.getThreadContent + Configuration.DELIMITER1 + treadID + Configuration.DELIMITER1 + subForumName
                + Configuration.DELIMITER1 + forumName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return serverResponse;
    }

    @Override
    public String getResponseContent(String treadID, String responseID, String subForumName, String forumName) {
        String serverResponse = "";
        this.msg = Configuration.getResponseContent + Configuration.DELIMITER1 + treadID + Configuration.DELIMITER1 + responseID
                + Configuration.DELIMITER1 + forumName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return serverResponse;
//        return "bla bla bla";
    }

    @Override
    public Vector<String> getThreadResponses(String forumName, String subForumName, String id) {
        String serverResponse = "";
        this.msg = Configuration.getThreadResponses + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName
                + Configuration.DELIMITER1 + id;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override
    public boolean publishNewThread(String forumName, String subForumName, String threadTitle, String threadContent, String userName) {
        String serverResponse = "";
        this.msg = Configuration.publishNewThread + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName
                + Configuration.DELIMITER1 + threadTitle + Configuration.DELIMITER1 + threadContent
                + Configuration.DELIMITER1 + userName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean postThreadResponse(String responseContent, String currentThreadTitle, String forumName, String subForumName, String userName, String id) {
        String serverResponse = "";
        this.msg = Configuration.postThreadResponse + Configuration.DELIMITER1 + responseContent + Configuration.DELIMITER1 + currentThreadTitle
                + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName
                + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + id;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean deleteThread(String id, String subForum, String Forum) {
        String serverResponse = "";
        this.msg = Configuration.deleteThread + Configuration.DELIMITER1 + id + Configuration.DELIMITER1 + subForum
                + Configuration.DELIMITER1 + Forum;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean deleteThreadResponse(String postID, String responseID, String forumName, String subForumName) {
        String serverResponse = "";
        this.msg = Configuration.deleteThreadResponse + Configuration.DELIMITER1 + postID + Configuration.DELIMITER1 + responseID
                + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean fileComplaint(String forumName, String subForumName, String moderatorUsername, String complaint, String userName, String password) {
        String serverResponse = "";
        this.msg = Configuration.fileComplaint + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName
                + Configuration.DELIMITER1 + moderatorUsername + Configuration.DELIMITER1 + complaint
                + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + password;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public Vector<String> getSubForumsForModerator(String forumName, String moderatorUserName) {
        String serverResponse = "";
        this.msg = Configuration.getSubForumsForModerator + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + moderatorUserName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public  boolean addAdminToForum(String forumName, String adminName) {
        String serverResponse = "";
        this.msg = Configuration.addAdminToForum + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + adminName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean removeAdminFromForum(String forumName, String adminName) {
       String serverResponse = "";
       this.msg = Configuration.removeAdminFromForum + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + adminName;
       try {
           //listenSocket();
           serverResponse = start();
       } catch (IOException ex) {
           java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
       }
       this.msg = null;
       return parser.parseToBool(serverResponse); 
    }

    @Override//
    public boolean validateByEmail(String userName,String forumName, String code) {
        String serverResponse = "";
        this.msg = Configuration.validateByEmail + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + code;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean addFriend(String forumName, String userName, String friendUserName) {
        String serverResponse = "";
        this.msg = Configuration.addFriend + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + userName
                 + Configuration.DELIMITER1 + friendUserName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean removeFriend(String userName, String forumName, String friendUserName) {
        String serverResponse = "";
        this.msg = Configuration.removeFriend + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName
                 + Configuration.DELIMITER1 + friendUserName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean responseToFreindRequest(String forumName, String userName, String friendUserName, String ans) {
        String serverResponse = "";
        this.msg = Configuration.responseToFreindRequest + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + userName
                 + Configuration.DELIMITER1 + friendUserName + Configuration.DELIMITER1 + ans;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean banMember(String userName, String forumName, String memberToBanName) {
        String serverResponse = "";
        this.msg = Configuration.banMember + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName
                 + Configuration.DELIMITER1 + memberToBanName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean editTread(String userName, String forum, String subForum, String treadID, String newText) {
        String serverResponse = "";
        this.msg = Configuration.editTread + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + subForum + Configuration.DELIMITER1 + treadID
                + Configuration.DELIMITER1 + newText;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override
    public boolean editResponse(String userName, String forum, String subForum, String treadID, String responseID, String newText) {
        String serverResponse = "";
        this.msg = Configuration.editResponse + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + subForum + Configuration.DELIMITER1 + treadID
                + Configuration.DELIMITER1 + responseID + Configuration.DELIMITER1 + newText;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean upgradeToModerator(String userName, String forum, String subForum, String moderatorUserName) {
        String serverResponse = "";
        this.msg = Configuration.upgradeToModerator + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + subForum + Configuration.DELIMITER1 + moderatorUserName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean banModerator(String userName, String forum, String subForum, String moderatorUserName) {
        String serverResponse = "";
        this.msg = Configuration.banModerator + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + subForum + Configuration.DELIMITER1 + moderatorUserName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean removeModerator(String userName, String forum, String subForum, String moderatorUserName) {
        String serverResponse = "";
        this.msg = Configuration.removeModerator + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + subForum + Configuration.DELIMITER1 + moderatorUserName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean replaceAdmin(String userName, String forum, String newAdminUserName) {
        String serverResponse = "";
        this.msg = Configuration.replaceAdmin + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + newAdminUserName;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean replaceModerator(String userName, String forum, String subForum, String newModeratorName, String oldModerator) {
        String serverResponse = "";
        this.msg = Configuration.replaceModerator + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + subForum + Configuration.DELIMITER1 + newModeratorName + Configuration.DELIMITER1 + oldModerator;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public int numOfPostsInSubForumReport(String userName, String forum, String subForum) {
        String serverResponse = "";
        this.msg = Configuration.numOfPostsInSubForumReport + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + subForum;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToInt(serverResponse);
    }

    @Override//
    public Vector<String> postsOfMemberReport(String userName, String forum, String memberName) {
        String serverResponse = "";
        this.msg = Configuration.postsOfMemberReport + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forum
                 + Configuration.DELIMITER1 + memberName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public Vector<String> listOfModeratorsReport(String userName, String forumName) {
        String serverResponse = "";
        this.msg = Configuration.listOfModeratorsReport + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public int numOfForumsReport() {
        String serverResponse = "";
        this.msg = Configuration.numOfForumsReport;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToInt(serverResponse);
    }

    @Override//
    public Vector<String> membersOfForum(String forumName) {
        String serverResponse = "";
        this.msg = Configuration.membersOfForum + Configuration.DELIMITER1 + forumName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public boolean createSubForum(String forumName, String subForumName, String subject, String moderatorUserName, String userName) {
       String serverResponse = "";
       this.msg = Configuration.createSubForum + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName
              + Configuration.DELIMITER1 + subject + Configuration.DELIMITER1 + moderatorUserName + Configuration.DELIMITER1 + userName;
       try {
           serverResponse = start();
       } catch (IOException ex) {
           java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
       }
       this.msg = null;
       return parser.parseToBool(serverResponse); 
    }

    @Override//
    public boolean deleteForum(String forumName) {
        String serverResponse = "";
       this.msg = Configuration.deleteForum + Configuration.DELIMITER1 + forumName;
       try {
           //listenSocket();
           serverResponse = start();
       } catch (IOException ex) {
           java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
       }
       this.msg = null;
       return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean deleteSubForum(String forumName, String subForumName) {
        String serverResponse = "";
       this.msg = Configuration.deleteSubForum + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName;
       try {
           //listenSocket();
           serverResponse = start();
       } catch (IOException ex) {
           java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
       }
       this.msg = null;
       return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean updateMemberType(String userName, String forumName, String type, String memberToUpdate) {
        this.msg = Configuration.updateMemberType + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName
                + Configuration.DELIMITER1 + memberToUpdate;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean createType(String userName, String forumName, String type) {
        this.msg = Configuration.createType + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName
                + Configuration.DELIMITER1 + type;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean isMember(String userName, String forumName) {
        this.msg = Configuration.isMember + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean isAdmin(String userName, String forumName) {
        this.msg = Configuration.isAdmin + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean isModerator(String userName, String forumName, String subforumName) {
        this.msg = Configuration.isModerator + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName
                 + Configuration.DELIMITER1 + subforumName;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean initializeSystem(String userName, String password) {
        this.msg = Configuration.initializeSystem + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + password;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean isInitialize() {
        this.msg = Configuration.isInitialize;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public boolean validateSuperAdmin(String userName, String password) {
       this.msg = Configuration.validateSuperAdmin + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + password;
       String serverResponse = null;
       try {
           //listenSocket();
           serverResponse = start();
           System.out.println("validateSuperAdmin: serverResponse is: " + serverResponse);
       } catch (IOException ex) {
           java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
       }
       this.msg = null;
       return parser.parseToBool(serverResponse);
    }

    @Override  //////////////////////////////// not sure ////////////////////////////////////
    public void notifyMember(String text) {
        this.msg = Configuration.notifyMember + Configuration.DELIMITER1 + text;
        String serverResponse = null;
        try {
           serverResponse = start();
           System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
    }

    @Override  //////////////////////////////// not sure ////////////////////////////////////
    public void notifyFreindRequest(String requesterUserName) {
        this.msg = Configuration.notifyFreindRequest + Configuration.DELIMITER1 + requesterUserName;
        String serverResponse = null;
        try {
           serverResponse = start();
           System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
    }

    @Override//
    public Vector<String> getAllAdminsInForum(String forumName) {
        this.msg = Configuration.getAllAdminsInForum + Configuration.DELIMITER1 + forumName;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public Vector<String> getAllModerators(String forumName, String subForumName) {
        this.msg = Configuration.getAllModerators + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + subForumName;
        String serverResponse = null;
        try {
            //listenSocket();
            serverResponse = start();
            System.out.println("validateSuperAdmin: serverResponse is: " + serverResponse);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

     
//    /*****************connect to server**********************************/
    
    public void listenSocket(){
        //Create socket connection
        try{
            //   InetAddress address = InetAddress.getByName(host);
            socket = new Socket("93.172.108.50", 8888);//("93.172.108.50", 6667);
            out = new PrintWriter(socket.getOutputStream(),
                    true);
            in = new BufferedReader(new InputStreamReader(
                    socket.getInputStream()));
        } catch (UnknownHostException e) {
            System.out.println("Unknown host: kq6py");
            System.exit(1);
        } catch  (IOException e) {
            System.out.println("No I/O");
            System.exit(1);
        }
    }
//    
//    
//        public void actionPerformed(ActionEvent event){
//           Object source = event.getSource();
//
//           if(source == button){
//            //Send data over socket
//              String text = textField.getText();
//              out.println(text);
//              textField.setText(new String(""));
//              out.println(text);
//           }
//           //Receive text from server
//           try{
//             String line = in.readLine();
//             System.out.println("Text received: " + line);
//           } catch (IOException e){
//             System.out.println("Read failed");
//             System.exit(1);
//           }
//        }


    @Override//
    public boolean createForum(String forumName, String userName, String hasEmailPolicy, String extendedDeletionPolicy, String minPostForModerator, String minSeniorityMonths, String onlyApointAdministratorCanRemoveModerators, String canRemoveSingleModerators, String expirationDateForPassword, String interactiveNotifyingPolicys) {
        String serverResponse = "";
        this.msg = Configuration.createForum + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + userName
              + Configuration.DELIMITER1 + hasEmailPolicy + Configuration.DELIMITER1 + extendedDeletionPolicy
        + Configuration.DELIMITER1 + minPostForModerator + Configuration.DELIMITER1 + minSeniorityMonths
                + Configuration.DELIMITER1 + onlyApointAdministratorCanRemoveModerators + Configuration.DELIMITER1 + canRemoveSingleModerators
        + Configuration.DELIMITER1 + expirationDateForPassword + Configuration.DELIMITER1 + interactiveNotifyingPolicys;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse); 
    }

    @Override//
    public boolean setPolicy(String forumName, String userName, String hasEmailPolicy, String extendedDeletionPolicy, String minPostForModerator, String minSeniorityMonths, String onlyApointAdministratorCanRemoveModerators, String canRemoveSingleModerators, String expirationDateForPassword, String interactiveNotifyingPolicys) {
        String serverResponse = "";
        this.msg = Configuration.setPolicy + Configuration.DELIMITER1 + forumName + Configuration.DELIMITER1 + userName
              + Configuration.DELIMITER1 + hasEmailPolicy + Configuration.DELIMITER1 + extendedDeletionPolicy
                + Configuration.DELIMITER1 + minPostForModerator
                 + Configuration.DELIMITER1 + minSeniorityMonths + Configuration.DELIMITER1 + onlyApointAdministratorCanRemoveModerators 
                  + Configuration.DELIMITER1 + canRemoveSingleModerators + Configuration.DELIMITER1 + expirationDateForPassword + Configuration.DELIMITER1 + interactiveNotifyingPolicys;
        try {
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(serverResponse);
    }

    @Override//
    public Vector<String> getMyPosts(String userName, String forumName) {
        String serverResponse = "";
        this.msg = Configuration.getMyPosts + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public Vector<String> getMyFreinds(String userName, String forumName) {
        String serverResponse = "";
        this.msg = Configuration.getMyFreinds + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public Vector<String> getMyRequests(String userName, String forumName) {
        String serverResponse = "";
        this.msg = Configuration.getMyRequests + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override//
    public Vector<String> getJoinedMemberInForums() {
        String serverResponse = "";
        this.msg = Configuration.getJoinedMemberInForums;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override
    public String loginSuper(String userName, String password) {
        String response = "";
        this.msg = Configuration.loginSuper +  Configuration.DELIMITER1
                + userName + Configuration.DELIMITER1 + password;
        try {
            //listenSocket();
            response = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return response;
    }

    @Override
    public Vector<String> getTypes(String forumName) {
        String serverResponse = "";
        this.msg = Configuration.getTypes + Configuration.DELIMITER1 + forumName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override
    public boolean deleteType(String forumName, String type) {
        String response = "";
        this.msg = Configuration.deleteType +  Configuration.DELIMITER1
                + forumName + Configuration.DELIMITER1 + type;
        try {
            //listenSocket();
            response = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(response);
    }

    @Override
    public boolean isItMyPost(String userName, String forumName, String subForum, String postID) {
        String response = "";
        this.msg = Configuration.isItMyPost +  Configuration.DELIMITER1 + userName + Configuration.DELIMITER1
                + forumName + Configuration.DELIMITER1 + subForum + Configuration.DELIMITER1 + postID;
        try {
            //listenSocket();
            response = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(response);
    }

    @Override
    public boolean isItMyResponse(String userName, String forumName, String subForum, String postID, String responseID) {
        String response = "";
        this.msg = Configuration.isItMyResponse +  Configuration.DELIMITER1 + userName + Configuration.DELIMITER1
                + forumName + Configuration.DELIMITER1 + subForum + Configuration.DELIMITER1 + postID
                + Configuration.DELIMITER1 + responseID;
        try {
            //listenSocket();
            response = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(response);
    }

    @Override
    public void exit() {
        String response = "";
        this.msg = Configuration.exit;
        try {
            //listenSocket();
            response = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
    }

    @Override
    public Vector<String> getNotifications(String userName, String forumName) {
        String serverResponse = "";
        this.msg = Configuration.getNotifications + Configuration.DELIMITER1 + userName + Configuration.DELIMITER1 + forumName;
        try {
            //listenSocket();
            serverResponse = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToVec(serverResponse);
    }

    @Override
    public boolean sendFriendRequest(String requesterName, String sendTo, String forumName) {
        String response = "";
        this.msg = Configuration.sendFriendRequest +  Configuration.DELIMITER1 + requesterName + Configuration.DELIMITER1
                + sendTo + Configuration.DELIMITER1 + forumName;
        try {
            //listenSocket();
            response = start();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(ConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.msg = null;
        return parser.parseToBool(response);
    }

    
}