/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/

package ClientSrc;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Vector;
import java.util.logging.Level;

/**
 *
 * @author Vali
 */
public class ProxyBaby implements ServerHandlerInterface{
    
    //proxy fields:
    private Vector<String> subForums = new Vector<String>();
    private Vector<String> forums = new Vector<String>();
    private Vector<String> admins = new Vector<String>();
    private Vector<String> moderators = new Vector<String>();
    private Vector<String> topics = new Vector<String>();
    private Vector<String> responses = new Vector<String>();
    private Vector<String> myPosts = new Vector<String>();
    private Vector<String> freinds = new Vector<String>();
    private Vector<String> requests = new Vector<String>();
    private Vector<String> types = new Vector<String>();
    private int id = 1;
   
    
    

    public ProxyBaby() {
        forums.add("Cats");
        forums.add("Dogs");
        forums.add("Sadna");
        subForums.add("Black Cats");
        subForums.add("White Cats");
        admins.add("TalHadad");
        admins.add("AsafShen");
        moderators.add("Sivan");
        moderators.add("Vali_007");
        topics.add(""+id+Configuration.DELIMITER2+"Make sound");
        id++;
        topics.add(""+id+Configuration.DELIMITER2+"Jump");
        id++;
        topics.add(""+id+Configuration.DELIMITER2+"Eat");
        id++;
        responses.add(""+id+Configuration.DELIMITER2+"Respons 1");
        id++;
        responses.add(""+id+Configuration.DELIMITER2+"Respons 2");
        id++;
        responses.add(""+id+Configuration.DELIMITER2+"Respons 3");
        id++;
        myPosts.add("title1"+Configuration.DELIMITER2+"subforum1"+Configuration.DELIMITER2+"forum1");
        myPosts.add("title2"+Configuration.DELIMITER2+"subforum2"+Configuration.DELIMITER2+"forum2");
        freinds.add("yossi");
        freinds.add("shola");
        requests.add("yossi2");
        requests.add("shola2");
        types.add("Gold");
        types.add("Silver");
    }



    @Override//
    public Vector<String> DisplayForums() {

        return forums;
            
    }

    @Override//
    public String registerToForum(String userName, String forumName, String password, String Email, String remainderQues, String remainderAns) {

        return Configuration.SUCCESS;
    }

    @Override//
    public String login(String forumName, String userName, String password) {

        return Configuration.SUCCESS + Configuration.DELIMITER1 + "SUPERADMINISTRATOR";
    }

    @Override//
    public boolean logout(String forumName, String userName) {

        return true;
    }

    @Override//
    public Vector<String> getSubForums(String forumName) {

        return subForums;
    }

    @Override//
    public Vector<String> getThreads(String forumName, String subForumName) {

        return topics;
    }

    @Override//
    public String getThreadContent(String treadID, String subForumName, String forumName) {

        return "bla bla bla";
    }

    @Override//
    public String getResponseContent(String treadID, String responseID, String subForumName, String forumName) {

        return "bla bla bla";
    }

    @Override//
    public Vector<String> getThreadResponses(String forumName, String subForumName, String id) {

        return responses;
    }

    @Override//
    public boolean publishNewThread(String forumName, String subForumName, String threadTitle, String threadContent, String userName) {

        topics.add(""+id+Configuration.DELIMITER2+threadTitle);
        id++;
        return true;
    }

    @Override//
    public boolean postThreadResponse(String responseContent, String currentThreadTitle, String forumName, String subForumName, String userName, String id) {

        responses.add(""+this.id+Configuration.DELIMITER2+currentThreadTitle);
        this.id++;
        return true;
    }

    @Override//
    public boolean deleteThread(String id, String subForum, String Forum) {

        String ans = Configuration.SUCCESS;
        for(int i=0; i<topics.size(); i++){
            if(topics.elementAt(i).endsWith(id))
                topics.removeElementAt(i);
        }
        return true;
    }

    @Override//
    public boolean deleteThreadResponse(String postID, String responseID, String forumName, String subForumName) {

        String ans = Configuration.SUCCESS;
        for(int i=0; i<responses.size(); i++){
            if(responses.elementAt(i).endsWith(responseID))
                responses.removeElementAt(i);
        }
        return true;
    }

    @Override//
    public boolean fileComplaint(String forumName, String subForumName, String moderatorUsername, String complaint, String userName, String password) {

        return true;
    }

    @Override//????????????????????????????????????????????????????????????????????
    public Vector<String> getSubForumsForModerator(String forumName, String moderatorUserName) {

        return null;
    }

    @Override//
    public boolean addAdminToForum(String forumName, String adminName) {

        String ans = Configuration.SUCCESS;
        admins.add(adminName);
        return true;
    }

    @Override//
    public boolean removeAdminFromForum(String forumName, String adminName) {

        admins.remove(adminName);
        return true;
    }

    @Override//
    public boolean validateByEmail(String userName,String forumName, String code) {

        return true;
    }

    @Override//
    public boolean addFriend(String forumName, String userName, String friendUserName) {

        return true;
    }

    @Override//
    public boolean removeFriend(String userName, String forumName, String friendUserName) {

        return true;
    }

    @Override//
    public boolean responseToFreindRequest(String forumName, String userName, String friendUserName, String ans) {

        return true;
    }

    @Override//
    public boolean banMember(String userName, String forumName, String memberToBanName) {

        return true;
    }

    @Override//
    public boolean editTread(String userName, String forum, String subForum, String treadID, String newText) {

        return true;
    }

    @Override//
    public boolean editResponse(String userName, String forum, String subForum, String treadID, String responseID, String newText) {

        return true;
    }

    @Override//
    public boolean upgradeToModerator(String userName, String forum, String subForum, String moderatorUserName) {

        moderators.add(moderatorUserName);
        return true;
    }

    @Override//
    public boolean banModerator(String userName, String forum, String subForum, String moderatorUserName) {

        return true;
    }

    @Override//
    public boolean removeModerator(String userName, String forum, String subForum, String moderatorUserName) {

        String ans = Configuration.SUCCESS;
        moderators.remove(moderatorUserName);
        return true;
    }

    @Override//
    public boolean replaceAdmin(String userName, String forum, String newAdminUserName) {

        admins.remove(userName);
        admins.add(newAdminUserName);
       return true;
    }

    @Override//
    public boolean replaceModerator(String userName, String forum, String subForum, String newModeratorName, String oldModerator) {

        moderators.remove(oldModerator);
        moderators.add(newModeratorName);
        return true;
    }

    @Override//
    public int numOfPostsInSubForumReport(String userName, String forum, String subForum) {

        return 4;
    }

    @Override//
    public Vector<String> postsOfMemberReport(String userName, String forum, String memberName) {

        return topics;
    }

    @Override//
    public Vector<String> listOfModeratorsReport(String userName, String forumName) {

        return moderators;
    }

    @Override//
    public int numOfForumsReport() {

        return 3;
    }

    @Override//
    public Vector<String> membersOfForum(String forumName) {

        return moderators;
    }

    @Override//
    public boolean createSubForum(String forumName, String subForumName, String subject, String moderatorUserName, String userName) {

        subForums.add(subForumName);
        return true;
    }

    @Override//
    public boolean deleteForum(String forumName) {

        forums.remove(forumName);
        return true;
    }

    @Override//
    public boolean deleteSubForum(String forumName, String subForumName) {

        subForums.remove(subForumName);
        return true;
    }

    @Override//
    public boolean updateMemberType(String userName, String forumName, String type, String memberToUpdate) {

        return true;
    }

    @Override//
    public boolean createType(String userName, String forumName, String type) {

        return true;
    }

    @Override//
    public boolean isMember(String userName, String forumName) {

        return true;
    }

    @Override//
    public boolean isAdmin(String userName, String forumName) {

        return true;
    }

    @Override//
    public boolean isModerator(String userName, String forumName, String subforumName) {

        return true;
    }

    @Override//
    public boolean initializeSystem(String userName, String password) {

        return true;
    }

    @Override//
    public boolean isInitialize() {

        return true;
    }

    @Override//
    public boolean validateSuperAdmin(String userName, String password) {

        return true;
    }

    @Override  //////////////////////////////// not sure ////////////////////////////////////
    public void notifyMember(String text) {
        
    }

    @Override  //////////////////////////////// not sure ////////////////////////////////////
    public void notifyFreindRequest(String requesterUserName) {
       
    }

    @Override//
    public Vector<String> getAllAdminsInForum(String forumName) {

        return admins;
    }

    @Override//
    public Vector<String> getAllModerators(String forumName, String subForumName) {

        return moderators;
    }

    @Override//
    public String loginSuper(String userName, String password) {

        return Configuration.SUCCESS;
    }

    @Override// need to add: String interactiveNotifyingPolicy
    public boolean createForum(String forumName, String userName, String hasEmailPolicy, String extendedDeletionPolicy, String minPostForModerator, String minSeniorityMonths, String onlyApointAdministratorCanRemoveModerators, String canRemoveSingleModerators, String expirationDateForPassword, String interactiveNotifyingPolicys) {

        forums.add(forumName);
        return true;        
    }

    @Override//
    public boolean setPolicy(String forumName, String userName, String hasEmailPolicy, String extendedDeletionPolicy, String minPostForModerator, String minSeniorityMonths, String onlyApointAdministratorCanRemoveModerators, String canRemoveSingleModerators, String expirationDateForPassword, String interactiveNotifyingPolicys) {
        return true;
    }

    @Override//
    public Vector<String> getMyPosts(String userName, String forumName) {
       
        return myPosts;
    }

    @Override//
    public Vector<String> getMyFreinds(String userName, String forumName) {
       
        return freinds;
    }

    @Override//
    public Vector<String> getMyRequests(String userName, String forumName) {
        
        return requests;
    }

    @Override//
    public Vector<String> getJoinedMemberInForums() {
        
        return freinds;
    }

    @Override//
    public Vector<String> getTypes(String forumName) {
        return types;
    }

    @Override//
    public boolean deleteType(String forumName, String type) {
        types.remove(type);
        return true;
    }

    @Override//
    public boolean isItMyPost(String userName, String forumName, String subForum, String postID) {
        return true;
    }

    @Override//
    public boolean isItMyResponse(String userName, String forumName, String subForum, String postID, String responseID) {
        return true;
    }

    @Override//
    public void exit() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Vector<String> getNotifications(String userName, String forumName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean sendFriendRequest(String requesterName, String sendTo, String forumName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}

/*
        //init all sub forum table:
        vec = handler.getSubForums(chosenForum);
         System.out.println("im DisplayForums!");
        if(vec == null){
            data = convertToArray(vec);
            String[] columnNames2 = {"Sub Forum Name"};
            allSubForumsModel = new DefaultTableModel(data, columnNames2);
            subForumTable.setModel(allSubForumsModel);
            subForumTable.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
            @Override
            public void valueChanged(ListSelectionEvent lse) {
                
                chosenSubForum = subForumTable.getValueAt(subForumTable.getSelectedRow(), 0).toString();
                topicsWelcomeToLabel.setText("Welcome To Sub Forum: " + chosenSubForum);
                CardLayout cl = (CardLayout)(mainPanel.getLayout());
                cl.first(mainPanel);
                cl.next(mainPanel);
                cl.next(mainPanel);
                if(!isGuest)
                    if(handler.isModerator(userName, chosenForum,chosenSubForum)) 
                        buttonAppearance("moderator");
            }
        });
        }
        //init all admins table;
        vec = handler.getAllAdminsInForum(chosenForum);
        if(vec == null){
            data = convertToArray(vec);
            String[] columnNames3 = {"Administrators"};
            adminsModel = new DefaultTableModel(data, columnNames3);
            adminsTable.setModel(adminsModel);
        }
        //init all topics table:
        vec = handler.getThreads(chosenForum,chosenSubForum);
        if(vec == null){
            data = convertToArray(vec);
            String[] columnNames4 = {"Topics Name"};
            allTopicsModel = new DefaultTableModel(data, columnNames4);
            topicsTable.setModel(allTopicsModel);
            topicsTable.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
            //private String chosenTopic;
            @Override
            public void valueChanged(ListSelectionEvent lse) {
                
                String topic = topicsTable.getValueAt(topicsTable.getSelectedRow(), 0).toString();
                String[] chosenTopicArr = topic.split(Configuration.DELIMITER2);//or substring like in responses table 
                for(int i=0; i<3; i++){
                    if(i!=2) chosenPost[i] = chosenTopicArr[i];
                    else  chosenPost[i] = handler.getThreadContent(chosenPost[0], chosenSubForum, chosenForum);
                }
                CardLayout cl = (CardLayout)(mainPanel.getLayout());
                responsesWelcomeToLabel.setText("TOPIC: " + chosenPost[1]);
                String content = handler.getThreadContent(chosenPost[0],chosenSubForum, chosenForum);
                //if(content.startsWith(Configuration.SUCCESS) ????????????????????????????????????????
                openingPostContentArea.setText(content);
                cl.last(mainPanel);
            }
        });
        }
        //init all moderator table;
        vec = handler.getAllModerators(chosenForum,chosenSubForum);
        if(vec == null){
            data = convertToArray(vec);
            String[] columnNames5 = {"Moderators"};
            moderatorsModel = new DefaultTableModel(data, columnNames5);
            moderatorsTable.setModel(moderatorsModel);
        }
        //init all responses table:
        vec = handler.getThreadResponses(chosenForum,chosenSubForum,chosenPost[0]);
        if(vec != null){
            data = convertToArray(vec);
            String[] columnNames6 = {"Response Name"};
            allResponsesPerTopicModel = new DefaultTableModel(data, columnNames6);
            responsesTable.setModel(allResponsesPerTopicModel);
            responsesTable.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
            @Override
            public void valueChanged(ListSelectionEvent lse) {
                String post = responsesTable.getValueAt(responsesTable.getSelectedRow(), 0).toString();
                String[] chosenPostArr = post.split(Configuration.DELIMITER2);
                for(int i=0; i<3; i++){   //{"id", "tltle", "content"}
                    if(i!=2) chosenResponse[i] = chosenPostArr[i];
                    else  chosenResponse[i] = handler.getResponseContent(chosenPost[0], chosenResponse[0], chosenSubForum, chosenForum);
                }
                JOptionPane.showMessageDialog(null, chosenResponse[2], chosenResponse[1], JOptionPane.PLAIN_MESSAGE);
            }
        });
        }
        */

     
                
                