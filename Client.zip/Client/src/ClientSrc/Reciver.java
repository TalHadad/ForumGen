/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package ClientSrc;

import java.io.*;
import java.net.*;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

/**
 *
 * @author sivan
 */
public class Reciver extends SwingWorker<String, Object>{
    
        BufferedReader in = null;
        PrintWriter out = null;
        String host = Configuration.IP;
        int port = Configuration.PORT;
        
        public void start() throws IOException {
            try {
               // Connect to Server
               Socket socket = new Socket(host, port);
               in = new BufferedReader( new InputStreamReader(socket.getInputStream()));
               out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
               System.out.println("Connected to server " + host + ":" + port);
            } catch (IOException ioe) {
               System.err.println("Can not establish connection to " +
                   host + ":" + port);
               ioe.printStackTrace();
               System.exit(-1);
            }

            try {
               // Read messages from the server and print them
                String message;
               while ((message=in.readLine()) != null) {
                   JOptionPane.showMessageDialog(null, message, "Response", JOptionPane.PLAIN_MESSAGE);
               }
            } catch (IOException ioe) {
               System.err.println("Connection to server broken.");
               ioe.printStackTrace();
            }
        }

        @Override
        protected String doInBackground() throws Exception {
            start();
            return "";
        }
    
}

/*

    SwingWorker<Boolean, Integer> worker = new SwingWorker<Boolean, Integer>() {
        @Override
        protected Boolean doInBackground() throws Exception {
            // Simulate doing something useful.
            for (int i = 0; i <= 10; i++) {
             Thread.sleep(1000);
             // The type we pass to publish() is determined
             // by the second template parameter.
             publish(i);
        }

        // Here we can return some object of whatever type
        // we specified for the first template parameter.
        // (in this case we're auto-boxing 'true').
        return true;

    }

 

 // Can safely update the GUI from this method.

 protected void done() {

  boolean status;

  try {

   // Retrieve the return value of doInBackground.

   status = get();

   statusLabel.setText('Completed with status: ' + status);

  } catch (InterruptedException e) {

   // This is thrown if the thread's interrupted.

  } catch (ExecutionException e) {

   // This is thrown if we throw an exception

   // from doInBackground.

  }  catch (ExecutionException ex) {
         Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
     }

 }

 

 @Override

 // Can safely update the GUI from this method.

 protected void process(List<Integer> chunks) {

  // Here we receive the values that we publish().

  // They may come grouped in chunks.

  int mostRecentValue = chunks.get(chunks.size()-1);

 

  countLabel1.setText(Integer.toString(mostRecentValue));

 }

};

worker.execute();

*/


   