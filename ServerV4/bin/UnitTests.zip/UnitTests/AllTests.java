
package UnitTests;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
import junit.framework.Test;
import junit.framework.TestSuite;
public class AllTests {
	
	public static void main(String[] args){
		junit.textui.TestRunner.run(suite());
	}
	
	public static Test suite(){
		TestSuite suite = new TestSuite("sysTest");
		suite.addTest(new TestSuite(TestAdministrator.class));
		suite.addTest(new TestSuite(TestFollowPost.class));
		suite.addTest(new TestSuite(TestForum.class));
		suite.addTest(new TestSuite(TestForumGen.class));
		suite.addTest(new TestSuite(TestGuest.class));
		suite.addTest(new TestSuite(TestLogger.class));
		suite.addTest(new TestSuite(TestMember.class));
		suite.addTest(new TestSuite(TestModeratoe.class));
		suite.addTest(new TestSuite(TestOpeningPost.class));
		suite.addTest(new TestSuite(TestPolicy.class));
		suite.addTest(new TestSuite(TestSecurity.class));
		suite.addTest(new TestSuite(TestSubForum.class));
		suite.addTest(new TestSuite(TestSuperAdmin.class));
		return suite;
	}
}