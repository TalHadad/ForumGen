package UnitTests;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestAdministrator {

}
