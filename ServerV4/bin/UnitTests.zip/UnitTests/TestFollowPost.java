package UnitTests;
import java.util.Vector;

import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;

public class TestFollowPost {
	
	protected FollowPost followPost;
	
	protected void setUp() throws Exception{
		Member member = new Member("user1","1234");
		followPost = new FollowPost(member,"followTitle","openPostContent");
	}

}
