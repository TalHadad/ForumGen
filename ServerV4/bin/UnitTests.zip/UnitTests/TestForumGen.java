package UnitTests;
import java.util.Vector;

import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
import junit.framework.TestCase;


public class TestForumGen extends TestCase{

protected ForumGen forumGen;
	
	protected void setUp() throws Exception{
		forumGen = new ForumGen("Yossi", "123"); 
	}
	
	//@Test
	public void testCreateForum(){
		Vector<String> forums = forumGen.displayForums();
		int size = forums.size();
		forumGen.createForum("Dogs", null, null);
		forums = forumGen.displayForums();
		assertEquals(forums.size(), size+1);
	}
	//@Test
	public void testDisplayForums(){
		String name="yosi";
		Administrator admin=new Administrator(name,"123");
		Forum forum=new Forum("cats",admin,null,null);
		int sizeForums = forumGen.getAmountOfForums();
		Vector<String> forums = forumGen.displayForums();
		int sizeListReturned = forums.size();
		assertEquals(sizeForums, sizeListReturned);
	}
	
}
