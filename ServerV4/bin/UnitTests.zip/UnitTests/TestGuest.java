package UnitTests;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestGuest {
	protected Guest guest;
	
	protected void setUp() throws Exception{
		guest = new Guest("guest12123");
	}

}
