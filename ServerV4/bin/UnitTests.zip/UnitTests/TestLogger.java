package UnitTests;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestLogger {
	protected Logger logger;
	
	protected void setUp() throws Exception{
		logger = new Logger();
	}

}
