package UnitTests;
import junit.framework.TestCase;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestMember extends TestCase{
	protected Member member;
	
	protected void setUp() throws Exception{
		member = new Moderator("memberName","pass1212");
	}

}
