package UnitTests;
import junit.framework.TestCase;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestModeratoe extends TestCase{
	protected Moderator moderator;
	
	protected void setUp() throws Exception{
		moderator = new Moderator("moderatorName","pass1212");
	}

}