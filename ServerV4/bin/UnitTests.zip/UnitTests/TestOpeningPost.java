package UnitTests;
import java.util.Vector;

import junit.framework.TestCase;

import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestOpeningPost extends TestCase{

	protected OpeningPost openingPost;
	
	protected void setUp() throws Exception{
		Member member = new Member("user1","1234");
		FollowPost followPost = new FollowPost(member,"followTitle","openPostContent");
		this.openingPost = new OpeningPost(member,"openPostTitle", "openPostContent"); 
	}
	
	//@Test
	public void testGetFollowPostsStringList(){
		Member member = new Member("user2","1234");
		FollowPost followPost = new FollowPost(member,"followPostTitle", "followPostContent"); 
		openingPost.addFollowPost(followPost); 
		int amountOfFollowPosts = openingPost.getFollowPosts().size();
		Vector<String> followPostsStringList = openingPost.getFollowPostsStringList();
		int amountOfListReturned = followPostsStringList.size();
		assertEquals(amountOfFollowPosts, amountOfListReturned);
	}
}
