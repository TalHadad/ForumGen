package UnitTests;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
import junit.framework.TestCase;
public class TestPolicy extends TestCase{
		protected Policy policy;
		
		protected void setUp() throws Exception{
			policy = new Policy("This is the policy",false);
		}

}