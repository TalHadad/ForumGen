package UnitTests;
import junit.framework.TestCase;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestSecurity extends TestCase{

	protected Security security;
	
	protected void setUp() throws Exception{
		security = new Security("This is the security policy");
	}

}
