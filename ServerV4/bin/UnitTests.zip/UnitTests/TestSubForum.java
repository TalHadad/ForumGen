package UnitTests;
import java.util.Vector;

import junit.framework.TestCase;

import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestSubForum extends TestCase{

	protected SubForum subForum;
	
	protected void setUp() throws Exception{
		subForum = new SubForum("This is the sub-forum name","This is the sub-forum subject");
	}
	
	//@Test
	public void testAddModerators(){
		Moderator moderator = new Moderator("moderator1","pass1234");
		int amountOfModeratorsBefore = subForum.getMederators().size();
		subForum.addModerator(moderator);
		int amountOfModeratorsAfter = subForum.getMederators().size();
		assertEquals(amountOfModeratorsBefore+1, amountOfModeratorsAfter);
	}
	//@Test
	public void testPostOpeningPost(){
		Member writer=new Member("member1","pass123");
		int amountOfOpeningPostsBefore = subForum.getOpeningPosts().size();
		subForum.postOpeningPost(writer,"this is the title","this is the content");
		int amountOfOpeningPostsAfter = subForum.getOpeningPosts().size();
		assertEquals(amountOfOpeningPostsBefore+1, amountOfOpeningPostsAfter);
	}
	//@Test
	public void testAddOpeningPost(){
		Member writer=new Member("member2","pass1234");
		int amountOfOpeningPostsBefore = subForum.getOpeningPosts().size();
		subForum.postOpeningPost(writer,"this is the title","this is the content");
		int amountOfOpeningPostsAfter = subForum.getOpeningPosts().size();
		assertEquals(amountOfOpeningPostsBefore+1, amountOfOpeningPostsAfter);
	}
	
}
