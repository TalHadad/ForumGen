package UnitTests;
import junit.framework.TestCase;
import Server.Users.*;
import Server.Forum.*;
import Server.Posts.*;
public class TestSuperAdmin extends TestCase{
	protected SuperAdmin superAdmin;
	
	protected void setUp() throws Exception{
		superAdmin = new SuperAdmin("TheSuperAdmin","pass1212");
	}

}
